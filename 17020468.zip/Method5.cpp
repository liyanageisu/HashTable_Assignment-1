#include<stdio.h>
#include<iostream>
#include<cstdlib>
#include<string>
#include<cstdio>

using namespace std;
const int table_size = 10;




class Hash_Table_Entry{
	public:
	int key;
	int value;
	
	Hash_Table_Entry(int key,int value){
		this->key=key;
		this->value= value;
	}
	
	
};

class Hash_Table_Mapping{
	
	private:
		Hash_Table_Entry **t;
	
	public:
	
	 Hash_Table_Mapping(){
		 t = new  Hash_Table_Entry * [table_size];
		 for(int i =0 ; i<table_size;i++){
	 		t[i] = NULL;
	 	}
	 	
	 }
	 
	 int HashFunction(int key){
	 	return key%table_size;
	 }
	 
	 void insert(int key, int value){
	 	
	 	int hash = HashFunction(key);
	 	while(t[hash] != NULL && t[hash]->key != key){
	 		hash = HashFunction(hash + 1);
	 		
		 }
		 
		 if(t[hash] != NULL){
		 	delete t[hash];
		 	t[hash] = new Hash_Table_Entry(key, value);
		 }
	 	
	 }
	 
	 int search(int key){
	 	int hash =  HashFunction(key);
	 		while(t[hash] != NULL && t[hash]->key != key){
	 		hash = HashFunction(hash + 1);
	 		
	 }
	 
	 if(t[hash] != NULL)
	 	return -1;
	 else
		 return t[hash]->value;
	
}
	
	void remove(int key){
		int hash =  HashFunction(key);
		while(t[hash] != NULL){
			if(t[hash]->key =key)
				break;
			hash = HashFunction(hash + 1);
		}
		
		if(t[hash] == NULL){
			cout<<"No element found at key "<<key<<endl;
			return;
		}else{
			delete t[hash];
		}
		
		cout<<"Element Deleted"<<endl;
		
	}
		
		~Hash_Table_Mapping() {
	
		for(int i =0 ; i<table_size;i++){
	 	if(t[i] = NULL)
	 		delete t[i];
	 		delete[] t;
	 	}
	 	
	 }
	 	
		
	
};

int main(){
	  Hash_Table_Mapping h;
   int key, value;
   int c;
   while (1) {
      cout<<"1.Insert element into the table"<<endl;
      cout<<"2.Search element from the key"<<endl;
      cout<<"3.Delete element at a key"<<endl;
      cout<<"4.Exit"<<endl;
      cout<<"Enter your choice: ";
      cin>>c;
      switch(c) {
         case 1:
            cout<<"Enter element to be inserted: ";
            cin>>value;
            cout<<"Enter key at which element to be inserted: ";
            cin>>key;
            h.insert(key, value);
         break;
         case 2:
            cout<<"Enter key of the element to be searched: ";
            cin>>key;
            if (h.search(key) == -1) {
               cout<<"No element found at key "<<key<<endl;
               continue;
            } else {
               cout<<"Element at key "<<key<<" : ";
               cout<<h.search(key)<<endl;
            }
         break;
         case 3:
            cout<<"Enter key of the element to be deleted: ";
            cin>>key;
            h.remove(key);
         break;
         case 4:
            exit(1);
         default:
            cout<<"\nEnter correct option\n";
      }
   }
   return 0;
}

	




